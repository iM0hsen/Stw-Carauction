# STW Car Auction


### التثبيت خطوة بخطوة
1) انسخ المجلد إلى مجلد الموارد:
   - ضع `stw-carauction` تحت `resources/`
   - أضف إلى server.cfg: `ensure stw-carauction`

2) قاعدة البيانات:
 [auction.sql]

3) إضافة الآيتم "بطاقة المزاد" في QBCore:
     ```lua
     ['auctioncard'] = {
       name = 'auctioncard',
       label = 'Auction Card',
       weight = 0,
       type = 'item',
       image = 'auctioncard.png',
       unique = true,
       useable = false,
       shouldClose = true,
       combinable = nil,
       description = 'Required to bid at car auctions'
     }
     ```


### Installation
1) Copy resource:
   - Place `stw-carauction` under `resources/[Main]/`
   - Add in server.cfg: `ensure stw-carauction`

2) Database:
   - insert [auction.sql]

3) Add the Auction Card item in QBCore:
   - In `QBCore.Shared.Items` (e.g., shared/items.lua):

     ```lua
     ['auctioncard'] = {
       name = 'auctioncard',
       label = 'Auction Card',
       weight = 0,
       type = 'item',
       image = 'auctioncard.png',
       unique = true,
       useable = false,
       shouldClose = true,
       combinable = nil,
       description = 'Required to bid at car auctions'
     }
     ```

   - Place the `auctioncard.png` in your inventory images folder.

local QBCore = exports['qb-core']:GetCoreObject()

print("||  Stw Free Car Auction Script | Join Our Discord: https://discord.gg/7vrxEge64p  || ")

local duiObj = nil
local duiUrl = "nui://" .. GetCurrentResourceName() .. "/html/index.html?view=dui"
local DUI_SIZE = {1920, 1080}
local AUCTION_OPEN_CMD = "auctionmenu"
local AUCTION_SETUP_CMD = "setupauction"

local auctionData = {
    vehicleLabel = "None",
    price = 0,
    bidder = "None",
    time = 0
}
local hasAuctionCard = false
local lastCardCheck = 0

Citizen.CreateThread(function()
    Wait(1000)

    local resolution = DUI_SIZE
    duiObj = CreateDui(duiUrl, resolution[1], resolution[2])
    
    local duiHandle = GetDuiHandle(duiObj)
    local txdName = "auction_dui_txd"
    local txnName = "auction_dui_txn"
    
    CreateRuntimeTextureFromDuiHandle(CreateRuntimeTxd(txdName), txnName, duiHandle)

    local tvLocations = {
        vector3(-1099.09, -1268.91, 7.26),
        vector3(-1088.86, -1262.75, 7.3)
    }

    local isReplaced = false

    while true do
        local sleep = 1000
        local playerCoords = GetEntityCoords(PlayerPedId())
        local nearAuctionTV = false
        
        for _, loc in ipairs(tvLocations) do
            local dist = #(playerCoords - loc)
            if dist < 30.0 then
                nearAuctionTV = true
                break
            end
        end

        if nearAuctionTV then
            AddReplaceTexture('xm_prop_x17_tv_ceiling_01', 'prop_base_black_01', txdName, txnName)
            isReplaced = true
            sleep = 100
        else
            if isReplaced then
                RemoveReplaceTexture('xm_prop_x17_tv_ceiling_01', 'prop_base_black_01')
                isReplaced = false
            end
            sleep = 1000
        end
        
        Wait(sleep)
    end
end)

RegisterNetEvent('stw-carauction:client:UpdateAuction', function(data)
    auctionData = data
    
    SendDuiMessage(duiObj, json.encode({
        type = "updateAuction",
        active = data.active,
        vehicleLabel = data.vehicleLabel,
        price = data.price,
        bidder = data.bidder,
        time = data.time
    }))

    SendNUIMessage({
        type = "updateAuction",
        active = data.active,
        vehicleLabel = data.vehicleLabel,
        price = data.price,
        bidder = data.bidder,
        time = data.time
    })
end)

RegisterCommand(AUCTION_OPEN_CMD, function()
    local playerCoords = GetEntityCoords(PlayerPedId())
    local dist = #(playerCoords - Config.PropCoords)
    
    if dist > 10.0 then
        QBCore.Functions.Notify("You are too far from the auction!", "error")
        return
    end

    openAuctionMenu()
end)

function openAuctionMenu()
    QBCore.Functions.TriggerCallback('stw-carauction:server:HasAuctionCard', function(has)
        hasAuctionCard = has
        local minBid = auctionData.minBid or Config.Auction.MinimumBid
        local menu = {
            {
                header = "Car Auction",
                isMenuHeader = true,
                icon = "fas fa-gavel"
            },
            {
                header = "Current Vehicle: " .. auctionData.vehicleLabel,
                txt = "Current Bid: $" .. auctionData.price .. " | Ends in: " .. auctionData.time .. "s",
                isMenuHeader = true,
                icon = "fas fa-car"
            }
        }
        if hasAuctionCard then
            table.insert(menu, {
                header = "Place Bid (+$" .. minBid .. ")",
                txt = "",
                icon = "fas fa-money-bill-wave",
                params = {
                    isServer = true,
                    event = "stw-carauction:server:PlaceBid",
                    args = {}
                }
            })
        else
            table.insert(menu, {
                header = "You need an Auction Card",
                isMenuHeader = true,
                icon = "fas fa-id-card"
            })
        end
        table.insert(menu, {
            header = "Close Menu",
            icon = "fas fa-times",
            params = {
                event = "qb-menu:client:closeMenu"
            }
        })
        exports['qb-menu']:openMenu(menu)
    end)
end

RegisterCommand(AUCTION_SETUP_CMD, function()
    TriggerServerEvent('stw-carauction:server:GetAuctionVehicles')
end)

local inAuctionZone = false

local function IsPointInPoly(point, poly)
    local x = point.x
    local y = point.y
    local inside = false
    local j = #poly
    for i = 1, #poly do
        local xi = poly[i].x
        local yi = poly[i].y
        local xj = poly[j].x
        local yj = poly[j].y
        local intersect = ((yi > y) ~= (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi) + xi)
        if intersect then inside = not inside end
        j = i
    end
    return inside
end

local function GetBoxPoly(center, length, width, heading)
    local rad = math.rad(-heading) 
    local cosT = math.cos(rad)
    local sinT = math.sin(rad)
    
    local halfW = width / 2
    local halfL = length / 2
    
    local corners = {
        vector2(-halfW, halfL),
        vector2(halfW, halfL),
        vector2(halfW, -halfL),
        vector2(-halfW, -halfL)
    }
    
    local poly = {}
    for i, p in ipairs(corners) do
        local newX = center.x + (p.x * cosT - p.y * sinT)
        local newY = center.y + (p.x * sinT + p.y * cosT)
        table.insert(poly, vector2(newX, newY))
    end
    
    return poly
end

local auctionPoly = GetBoxPoly(Config.AuctionZone.center, Config.AuctionZone.length, Config.AuctionZone.width, Config.AuctionZone.heading)
local garagePoly = GetBoxPoly(Config.GarageZone.center, Config.GarageZone.length, Config.GarageZone.width, Config.GarageZone.heading)

local function IsInAuctionZone(coords)
    if coords.z < Config.AuctionZone.minZ or coords.z > Config.AuctionZone.maxZ then
        return false
    end
    
    return IsPointInPoly(vector2(coords.x, coords.y), auctionPoly)
end

local function IsInGarageZone(coords)
    if coords.z < Config.GarageZone.minZ or coords.z > Config.GarageZone.maxZ then
        return false
    end
    
    return IsPointInPoly(vector2(coords.x, coords.y), garagePoly)
end

local inGarageZone = false
local auctionVehicle = nil
local auctionPed = nil
local cardShopPed = nil

RegisterNetEvent('stw-carauction:client:SpawnAndDrive', function(vehData, price, time)
    QBCore.Functions.SpawnVehicle(vehData.vehicle, function(veh)
        auctionVehicle = veh
        SetEntityCoords(veh, Config.AuctionDriveStart.x, Config.AuctionDriveStart.y, Config.AuctionDriveStart.z)
        SetEntityHeading(veh, Config.AuctionDriveStart.w)
        SetVehicleNumberPlateText(veh, vehData.plate)
        
        if vehData.mods then
            QBCore.Functions.SetVehicleProperties(veh, json.decode(vehData.mods))
        end
        
        local model = `a_m_y_business_01`
        RequestModel(model)
        while not HasModelLoaded(model) do Wait(0) end
        
        auctionPed = CreatePed(4, model, Config.AuctionDriveStart.x, Config.AuctionDriveStart.y, Config.AuctionDriveStart.z, Config.AuctionDriveStart.w, true, true)
        SetPedIntoVehicle(auctionPed, veh, -1)
        
        TaskVehicleDriveToCoord(auctionPed, veh, Config.AuctionDriveSpot.x, Config.AuctionDriveSpot.y, Config.AuctionDriveSpot.z, 6.0, 0, 16777216, 1.0, true)
        
        local netId = NetworkGetNetworkIdFromEntity(veh)
        TriggerServerEvent('stw-carauction:server:ConfirmStartAuction', netId, vehData, price, time, minBid)
        
        CreateThread(function()
            local startTime = GetGameTimer()
            while auctionPed and DoesEntityExist(auctionPed) do
                local coords = GetEntityCoords(auctionPed)
                local dist = #(coords - vector3(Config.AuctionDriveSpot.x, Config.AuctionDriveSpot.y, Config.AuctionDriveSpot.z))
                
                if dist < 2.0 then
                    TaskVehicleTempAction(auctionPed, veh, 27, -1)
                    SetEntityCoords(veh, Config.AuctionDriveSpot.x, Config.AuctionDriveSpot.y, Config.AuctionDriveSpot.z, false, false, false, true)
                    SetEntityHeading(veh, Config.AuctionDriveSpot.w)
                    SetVehicleOnGroundProperly(veh)
                    SetVehicleHandbrake(veh, true)
                    break
                end
                
                if GetGameTimer() - startTime > 20000 then
                     SetEntityCoords(veh, Config.AuctionDriveSpot.x, Config.AuctionDriveSpot.y, Config.AuctionDriveSpot.z)
                     SetEntityHeading(veh, Config.AuctionDriveSpot.w)
                     TaskVehicleTempAction(auctionPed, veh, 27, -1)
                     break
                end
                
                Wait(500)
            end
        end)
    end, Config.AuctionDriveStart, true)
end)

RegisterNetEvent('stw-carauction:client:DeliverVehicle', function(hasWinner)
    if auctionVehicle and DoesEntityExist(auctionVehicle) and auctionPed and DoesEntityExist(auctionPed) then
        SetVehicleHandbrake(auctionVehicle, false)
        
        TaskVehicleDriveToCoord(auctionPed, auctionVehicle, Config.AuctionDriveBuySpot.x, Config.AuctionDriveBuySpot.y, Config.AuctionDriveBuySpot.z, 6.0, 0, 16777216, 1.0, true)
        
        CreateThread(function()
            local startTime = GetGameTimer()
            while auctionPed and DoesEntityExist(auctionPed) do
                local coords = GetEntityCoords(auctionPed)
                local dist = #(coords - vector3(Config.AuctionDriveBuySpot.x, Config.AuctionDriveBuySpot.y, Config.AuctionDriveBuySpot.z))
                
                if dist < 5.0 then
                    TaskVehicleTempAction(auctionPed, auctionVehicle, 27, 2000)
                    SetEntityCoords(auctionVehicle, Config.AuctionDriveBuySpot.x, Config.AuctionDriveBuySpot.y, Config.AuctionDriveBuySpot.z, false, false, false, true)
                    SetEntityHeading(auctionVehicle, Config.AuctionDriveBuySpot.w)
                    SetVehicleOnGroundProperly(auctionVehicle)
                    
                    if hasWinner then
                        SetVehicleDoorsLocked(auctionVehicle, 1)
                        SetVehicleDoorsLockedForAllPlayers(auctionVehicle, false)

                        Wait(200)
                        TaskLeaveVehicle(auctionPed, auctionVehicle, 0)
                        Wait(2000)
                        
                        TaskWanderStandard(auctionPed, 10.0, 10)
                        Wait(3000)
                        DeleteEntity(auctionPed)
                        auctionPed = nil
                    else
                        DeleteEntity(auctionVehicle)
                        DeleteEntity(auctionPed)
                        auctionVehicle = nil
                        auctionPed = nil
                    end
                    break
                end
                
                if GetGameTimer() - startTime > 30000 then
                     SetEntityCoords(auctionVehicle, Config.AuctionDriveBuySpot.x, Config.AuctionDriveBuySpot.y, Config.AuctionDriveBuySpot.z)
                     SetEntityHeading(auctionVehicle, Config.AuctionDriveBuySpot.w)
                     SetVehicleOnGroundProperly(auctionVehicle)
                     
                     if hasWinner then
                         SetVehicleDoorsLocked(auctionVehicle, 1)
                         SetVehicleDoorsLockedForAllPlayers(auctionVehicle, false)

                         TaskLeaveVehicle(auctionPed, auctionVehicle, 0)
                         Wait(2000)
                         DeleteEntity(auctionPed)
                         auctionPed = nil
                     else
                         DeleteEntity(auctionVehicle)
                         DeleteEntity(auctionPed)
                         auctionVehicle = nil
                         auctionPed = nil
                     end
                     break
                end
                
                Wait(1000)
            end
        end)
    end
end)

RegisterNetEvent('stw-carauction:client:OpenEmployeeMenu', function(employees)
    local menu = {
        {
            header = "Employee Management",
            isMenuHeader = true,
            icon = "fas fa-users"
        }
    }
    
    for _, emp in ipairs(employees) do
        local status = emp.isOnline and "🟢 Online" or "🔴 Offline"
        menu[#menu+1] = {
            header = emp.name .. " (" .. emp.grade.name .. ")",
            txt = status,
            icon = "fas fa-user",
            params = {
                event = "stw-carauction:client:ManageEmployee",
                args = {
                    name = emp.name,
                    citizenid = emp.citizenid,
                    grade = emp.grade.level
                }
            }
        }
    end
    
    menu[#menu+1] = {
        header = "Hire New Employee",
        txt = "Hire nearest person",
        icon = "fas fa-plus",
        params = {
            event = "stw-carauction:client:HireMenu"
        }
    }

    menu[#menu+1] = {
        header = "Back",
        icon = "fas fa-arrow-left",
        params = {
            event = "stw-carauction:client:OpenBossMenu"
        }
    }
    
    exports['qb-menu']:openMenu(menu)
end)

RegisterNetEvent('stw-carauction:client:ManageEmployee', function(data)
    local menu = {
        {
            header = "Manage: " .. data.name,
            isMenuHeader = true,
            icon = "fas fa-user-cog"
        },
        {
            header = "Promote",
            txt = "Promote to next grade",
            params = {
                isServer = true,
                event = "stw-carauction:server:PromoteEmployee",
                args = {
                    citizenid = data.citizenid,
                    newGrade = data.grade + 1
                }
            }
        },
        {
            header = "Demote",
            txt = "Demote to previous grade",
            params = {
                isServer = true,
                event = "stw-carauction:server:PromoteEmployee",
                args = {
                    citizenid = data.citizenid,
                    newGrade = data.grade - 1
                }
            }
        },
        {
            header = "Fire",
            txt = "Fire this employee",
            params = {
                isServer = true,
                event = "stw-carauction:server:FireEmployee",
                args = {
                    citizenid = data.citizenid
                }
            }
        },
        {
            header = "Back",
            icon = "fas fa-arrow-left",
            params = {
                isServer = true,
                event = "stw-carauction:server:GetEmployees"
            }
        }
    }
    exports['qb-menu']:openMenu(menu)
end)

RegisterNetEvent('stw-carauction:client:HireMenu', function()
    local player, distance = QBCore.Functions.GetClosestPlayer()
    if player ~= -1 and distance < 2.5 then
        local playerId = GetPlayerServerId(player)
        TriggerServerEvent('stw-carauction:server:HireEmployee', playerId)
    else
        QBCore.Functions.Notify("No one nearby!", "error")
    end
end)

RegisterNetEvent('stw-carauction:client:OpenBossMenu', function()
    TriggerEvent('stw-carauction:client:OpenMainBossMenu')
end)

RegisterNetEvent('stw-carauction:client:OpenMainBossMenu', function()
    local menu = {
        {
            header = "Auction Management",
            isMenuHeader = true,
            icon = "fas fa-user-tie"
        },
        {
            header = "Employee Management",
            txt = "",
            icon = "fas fa-users",
            params = {
                isServer = true,
                event = "stw-carauction:server:GetEmployees",
            }
        },
        {
            header = "Auction Funds",
            txt = "",
            icon = "fas fa-wallet",
            params = {
                isServer = true,
                event = "stw-carauction:server:GetAuctionBalance"
            }
        },
        {
            header = "Close Menu",
            icon = "fas fa-times",
            params = {
                event = "qb-menu:client:closeMenu"
            }
        }
    }
    exports['qb-menu']:openMenu(menu)
end)

local function openCardShopMenu()
    local price = Config.AuctionCardPrice
    local menu = {
        {
            header = "Auction Card",
            isMenuHeader = true,
            icon = "fas fa-id-card"
        },
        {
            header = "Buy Card",
            txt = "$" .. price,
            icon = "fas fa-credit-card",
            params = {
                isServer = true,
                event = "stw-carauction:server:BuyAuctionCard"
            }
        },
        {
            header = "Close",
            icon = "fas fa-times",
            params = {
                event = "qb-menu:client:closeMenu"
            }
        }
    }
    exports['qb-menu']:openMenu(menu)
end

CreateThread(function()
    local model = `a_m_y_business_01`
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(0) end
    local pos = Config.AuctionCardPed
    cardShopPed = CreatePed(4, model, pos.x, pos.y, pos.z, pos.w, false, true)
    FreezeEntityPosition(cardShopPed, true)
    SetEntityInvincible(cardShopPed, true)
    SetBlockingOfNonTemporaryEvents(cardShopPed, true)
    RequestAnimDict("missfbi4prepp1")
    while not HasAnimDictLoaded("missfbi4prepp1") do Wait(0) end
    TaskPlayAnim(cardShopPed, "missfbi4prepp1", "idle_a", 8.0, -8.0, -1, 1, 0, false, false, false)
end)

CreateThread(function()
    while true do
        local sleep = 500
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        
        if IsInAuctionZone(coords) then
            inAuctionZone = true
            sleep = 5
            
            if auctionData.active then
                if GetGameTimer() - lastCardCheck > 1500 then
                    lastCardCheck = GetGameTimer()
                    QBCore.Functions.TriggerCallback('stw-carauction:server:HasAuctionCard', function(has)
                        hasAuctionCard = has
                        SendNUIMessage({
                            type = "toggleBiddingUI",
                            visible = hasAuctionCard
                        })
                    end)
                end
                if hasAuctionCard and IsControlJustPressed(0, 38) then
                    TriggerServerEvent('stw-carauction:server:PlaceBid')
                elseif not hasAuctionCard and IsControlJustPressed(0, 38) then
                    QBCore.Functions.Notify("You need an Auction Card", "error")
                end
            else
                SendNUIMessage({
                    type = "toggleBiddingUI",
                    visible = false
                })
            end
        else
            if inAuctionZone then
                inAuctionZone = false
                SendNUIMessage({
                    type = "toggleBiddingUI",
                    visible = false
                })
            end
        end

        if IsInGarageZone(coords) then
            inGarageZone = true
            sleep = 5
            
            local isDriver = IsPedInAnyVehicle(ped, false) and GetPedInVehicleSeat(GetVehiclePedIsIn(ped, false), -1) == ped
            
            if isDriver then
                exports['qb-ui']:DrawText('Store Vehicle in Auction', 'fa-solid fa-e')
                if IsControlJustPressed(0, 38) then -- E Key
                    local vehicle = GetVehiclePedIsIn(ped, false)
                    local props = QBCore.Functions.GetVehicleProperties(vehicle)
                    TriggerServerEvent('stw-carauction:server:StoreVehicle', props)
                end
            end
        else
            if inGarageZone then
                inGarageZone = false
                exports['qb-ui']:HideText()
            end
        end
        
        if cardShopPed and DoesEntityExist(cardShopPed) then
            local d = #(coords - vector3(Config.AuctionCardPed.x, Config.AuctionCardPed.y, Config.AuctionCardPed.z))
            if d < 2.0 then
                if IsControlJustPressed(0, 38) then
                    openCardShopMenu()
                end
                sleep = 5
            end
        end
        
        Wait(sleep)
    end
end)

CreateThread(function()
    exports.interact:AddInteraction({
        coords = Config.BossMenu,
        distance = 5.0,
        interactDst = 2.0,
        id = 'auction_manager_zone',
        name = 'auction_manager',
        groups = {
            [Config.Job.name] = Config.Job.minGradeStart
        },
        options = {
            {
                label = 'Toggle Duty',
                action = function(entity, coords, args)
                    TriggerServerEvent('stw-carauction:server:ToggleDuty')
                end,
            },
            {
                label = 'Start Auction',
                canInteract = function(entity, distance, data)
                    local PlayerData = QBCore.Functions.GetPlayerData()
                    return PlayerData.job.onduty
                end,
                action = function(entity, coords, args)
                    ExecuteCommand(AUCTION_SETUP_CMD)
                end,
            },
            {
                label = 'Boss Menu',
                canInteract = function(entity, distance, data)
                    local PlayerData = QBCore.Functions.GetPlayerData()
                    return PlayerData.job.onduty and PlayerData.job.grade.level >= Config.Job.minGradeManager
                end,
                action = function(entity, coords, args)
                    local PlayerData = QBCore.Functions.GetPlayerData()
                    if PlayerData.job.name == Config.Job.name and PlayerData.job.grade.level >= Config.Job.minGradeManager then
                        local menu = {
                            {
                                header = "Auction Management",
                                isMenuHeader = true,
                                icon = "fas fa-user-tie"
                            },
                            {
                                header = "Employee Management",
                                txt = "Hire, Fire, and Manage Employees",
                                icon = "fas fa-users",
                                params = {
                                    isServer = true,
                                    event = "stw-carauction:server:GetEmployees",
                                }
                            },
                            {
                            header = "Auction Funds",
                            txt = "Manage Auction Money",
                            icon = "fas fa-wallet",
                            params = {
                                isServer = true,
                                event = "stw-carauction:server:GetAuctionBalance"
                            }
                        },
                        {
                            header = "Close Menu",
                            icon = "fas fa-times",
                            params = {
                                event = "qb-menu:client:closeMenu"
                            }
                        }
                    }
                    exports['qb-menu']:openMenu(menu)
                else
                    QBCore.Functions.Notify("Authorized personnel only (Manager+)", "error")
                end
            end,
        },
        }
    })
end)

CreateThread(function()
    exports.interact:AddInteraction({
        coords = vector3(Config.AuctionCardPed.x, Config.AuctionCardPed.y, Config.AuctionCardPed.z + 1.0),
        distance = 5.0,
        interactDst = 2.0,
        id = 'auction_card_shop',
        name = 'auction_card_shop',
        options = {
            {
                label = 'Buy Auction Card',
                action = function(entity, coords, args)
                    openCardShopMenu()
                end,
            }
        },
    })
end)

RegisterNetEvent('stw-carauction:client:OpenAuctionSetupList', function(vehicles)
    local menu = {
        {
            header = "Auction Garage Vehicles",
            isMenuHeader = true,
            icon = "fas fa-warehouse"
        }
    }

    for _, v in ipairs(vehicles) do
        local label = v.vehicle
        if QBCore.Shared.Vehicles[v.vehicle] then
            label = QBCore.Shared.Vehicles[v.vehicle].name
        end

        table.insert(menu, {
            header = label .. " [" .. v.plate .. "]",
            txt = "Owner: " .. v.citizenid,
            icon = "fas fa-car",
            params = {
                event = "stw-carauction:client:SetupAuctionDetails",
                args = {
                    vehicleData = v
                }
            }
        })
    end

    table.insert(menu, {
        header = "Close Menu",
        icon = "fas fa-times",
        params = {
            event = "qb-menu:client:closeMenu"
        }
    })

    exports['qb-menu']:openMenu(menu)
end)

RegisterNetEvent('stw-carauction:client:SetupAuctionDetails', function(data)
    local dialog = exports['qb-input']:ShowInput({
        header = "Start Auction for " .. data.vehicleData.plate,
        submitText = "Start Auction",
        inputs = {
            {
                text = "Starting Price",
                name = "price",
                type = "number", 
                isRequired = true
            },
            {
                text = "Auction Duration (Seconds)",
                name = "time",
                type = "number", 
                isRequired = true,
                default = Config.Auction.InitialTime
            },
            {
                text = "Minimum Bid Increment ($)",
                name = "minBid",
                type = "number", 
                isRequired = true,
                default = Config.Auction.MinimumBid
            }
        }
    })

    if dialog then
        if not dialog.price or not dialog.time or not dialog.minBid then return end
        
        TriggerServerEvent('stw-carauction:server:StartAuctionFromGarage', data.vehicleData.id, dialog.price, dialog.time, dialog.minBid)
    end
end)

RegisterNetEvent('stw-carauction:client:OpenEmployeeMenu', function(employees)
    local menu = {
        {
            header = "Employee Management",
            isMenuHeader = true,
            icon = "fas fa-users"
        },
        {
            header = "Hire New Employee",
            txt = "Hire a nearby person",
            icon = "fas fa-user-plus",
            params = {
                event = "stw-carauction:client:HireInput"
            }
        }
    }

    for _, emp in ipairs(employees) do
        table.insert(menu, {
            header = emp.name .. " (" .. emp.grade.name .. ")",
            txt = emp.isOnline and "Online" or "Offline",
            icon = "fas fa-user",
            params = {
                event = "stw-carauction:client:ManageEmployee",
                args = {
                    employee = emp
                }
            }
        })
    end

    table.insert(menu, {
        header = "Close Menu",
        icon = "fas fa-times",
        params = {
            event = "qb-menu:client:closeMenu"
        }
    })

    exports['qb-menu']:openMenu(menu)
end)

RegisterNetEvent('stw-carauction:client:HireInput', function()
    local dialog = exports['qb-input']:ShowInput({
        header = "Hire Employee",
        submitText = "Hire",
        inputs = {
            {
                text = "Target Player ID",
                name = "id",
                type = "number",
                isRequired = true
            }
        }
    })

    if dialog then
        if not dialog.id then return end
        TriggerServerEvent('stw-carauction:server:HireEmployee', dialog.id)
    end
end)

RegisterNetEvent('stw-carauction:client:ManageEmployee', function(data)
    local emp = data.employee
    local menu = {
        {
            header = "Manage: " .. emp.name,
            isMenuHeader = true,
            icon = "fas fa-user-cog"
        },
        {
            header = "Promote/Demote",
            txt = "Current Grade: " .. emp.grade.level,
            icon = "fas fa-sort-amount-up",
            params = {
                event = "stw-carauction:client:GradeInput",
                args = {
                    employee = emp
                }
            }
        },
        {
            header = "Fire Employee",
            txt = "Remove from job",
            icon = "fas fa-user-slash",
            params = {
                isServer = true,
                event = "stw-carauction:server:FireEmployee",
                args = emp.citizenid
            }
        },
        {
            header = "Back",
            icon = "fas fa-arrow-left",
            params = {
                isServer = true,
                event = "stw-carauction:server:GetEmployees"
            }
        }
    }
    exports['qb-menu']:openMenu(menu)
end)

RegisterNetEvent('stw-carauction:client:GradeInput', function(data)
    local emp = data.employee
    local dialog = exports['qb-input']:ShowInput({
        header = "Change Grade for " .. emp.name,
        submitText = "Update",
        inputs = {
            {
                text = "New Grade Level (0-" .. Config.Job.minGradeManager .. ")",
                name = "grade",
                type = "number",
                isRequired = true
            }
        }
    })

    if dialog then
        if not dialog.grade then return end
        TriggerServerEvent('stw-carauction:server:PromoteEmployee', emp.citizenid, dialog.grade)
    end
end)

RegisterNetEvent('stw-carauction:client:OpenMoneyMenu', function(balance)
    local menu = {
        {
            header = "Auction Funds",
            isMenuHeader = true,
            icon = "fas fa-coins"
        },
        {
            header = "Current Balance: $" .. comma_value(balance),
            isMenuHeader = true,
            icon = "fas fa-info-circle"
        },
        {
            header = "Withdraw Money",
            txt = "Withdraw funds to your cash",
            icon = "fas fa-hand-holding-usd",
            params = {
                event = "stw-carauction:client:WithdrawInput",
                args = {
                    balance = balance
                }
            }
        },
        {
            header = "Back",
            icon = "fas fa-arrow-left",
            params = {
                event = "qb-menu:client:closeMenu"
            }
        }
    }
    exports['qb-menu']:openMenu(menu)
end)

RegisterNetEvent('stw-carauction:client:WithdrawInput', function(data)
    local dialog = exports['qb-input']:ShowInput({
        header = "Withdraw Money",
        submitText = "Withdraw",
        inputs = {
            {
                text = "Amount (Max: $" .. comma_value(data.balance) .. ")",
                name = "amount",
                type = "number",
                isRequired = true
            }
        }
    })

    if dialog then
        if not dialog.amount then return end
        local amount = tonumber(dialog.amount)
        if amount and amount > 0 then
            TriggerServerEvent('stw-carauction:server:WithdrawMoney', amount)
        else
            QBCore.Functions.Notify("Invalid amount", "error")
        end
    end
end)

RegisterNetEvent('stw-carauction:client:SpawnWonVehicle', function(model, plate, mods)
    local ped = PlayerPedId()
    QBCore.Functions.LoadModel(model)
    local coords = Config.AuctionDriveBuySpot
    local veh = CreateVehicle(model, coords.x, coords.y, coords.z, coords.w, true, false)
    SetVehicleNumberPlateText(veh, plate)
    QBCore.Functions.SetVehicleProperties(veh, mods)
    TriggerEvent("vehiclekeys:client:SetOwner", QBCore.Functions.GetPlate(veh))
end)

function comma_value(n)
	local left,num,right = string.match(n,'^([^%d]*%d)(%d*)(.-)$')
	return left..(num:reverse():gsub('(%d%d%d)','%1,'):reverse())..right
end

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        if duiObj then
            DestroyDui(duiObj)
        end
    end
end)

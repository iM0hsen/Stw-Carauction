local QBCore = exports['qb-core']:GetCoreObject()

print("||  Stw Free Car Auction Script | Join Our Discord: https://discord.gg/7vrxEge64p  ||")

local AuctionState = {
    active = false,
    vehicleLabel = "None",
    price = 0,
    bidder = "None",
    bidderSource = nil,
    bidderCitizenId = nil,
    time = 0,
    vehicleData = nil
}

local function CheckJobPermission(source, minGrade)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return false end
    if Player.PlayerData.job.name == Config.Job.name and Player.PlayerData.job.grade.level >= minGrade then
        return true
    end
    return false
end

RegisterNetEvent('stw-carauction:server:StartAuctionFromMenu', function(vehicle, price)
    local src = source
    if not QBCore.Functions.HasPermission(src, 'admin') and not CheckJobPermission(src, Config.Job.minGradeStart) then
        TriggerClientEvent('QBCore:Notify', src, 'Access Denied', 'error')
        return
    end

    if not vehicle or not price then return end
    
    StartAuction({vehicle = vehicle, plate = "Unknown"}, tonumber(price))
end)

RegisterNetEvent('stw-carauction:server:StoreVehicle', function(mods)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    
    if not CheckJobPermission(src, 0) then
        TriggerClientEvent('QBCore:Notify', src, 'Access Denied', 'error')
        return
    end

    local plate = mods.plate
    
    local result = MySQL.query.await('SELECT * FROM player_vehicles WHERE plate = ? AND citizenid = ?', {plate, Player.PlayerData.citizenid})
    
    if result and result[1] then
        local vehInfo = result[1]
        MySQL.query('DELETE FROM player_vehicles WHERE plate = ?', {plate})
        
        MySQL.insert('INSERT INTO auction_vehicles (citizenid, license, vehicle, hash, mods, plate, state) VALUES (?, ?, ?, ?, ?, ?, ?)', {
            Player.PlayerData.citizenid,
            Player.PlayerData.license,
            vehInfo.vehicle,
            vehInfo.hash,
            json.encode(mods),
            plate,
            0
        })
        
        TriggerClientEvent('QBCore:Notify', src, 'Vehicle stored in Auction Garage', 'success')
        
        local ped = GetPlayerPed(src)
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 then DeleteEntity(veh) end
    else
        TriggerClientEvent('QBCore:Notify', src, 'You do not own this vehicle', 'error')
    end
end)

RegisterNetEvent('stw-carauction:server:GetAuctionVehicles', function()
    local src = source
    if not QBCore.Functions.HasPermission(src, 'admin') and not CheckJobPermission(src, Config.Job.minGradeStart) then
        TriggerClientEvent('QBCore:Notify', src, 'Access Denied', 'error')
        return
    end
    
    local result = MySQL.query.await('SELECT * FROM auction_vehicles WHERE state = 0')
    TriggerClientEvent('stw-carauction:client:OpenAuctionSetupList', src, result)
end)

RegisterNetEvent('stw-carauction:server:StartAuctionFromGarage', function(vehicleId, price, time, minBid)
    local src = source
    if not QBCore.Functions.HasPermission(src, 'admin') and not CheckJobPermission(src, Config.Job.minGradeStart) then return end

    local result = MySQL.query.await('SELECT * FROM auction_vehicles WHERE id = ?', {vehicleId})
    if result and result[1] then
        local vehData = result[1]
        TriggerClientEvent('stw-carauction:client:SpawnAndDrive', src, vehData, tonumber(price), tonumber(time), tonumber(minBid))
    end
end)

RegisterNetEvent('stw-carauction:server:ConfirmStartAuction', function(netId, vehData, price, time, minBid)
    local src = source
    if not CheckJobPermission(src, Config.Job.minGradeStart) then return end

    StartAuction(vehData, price, time, minBid, src, netId)

    if vehData.id then
        MySQL.update('UPDATE auction_vehicles SET state = 1 WHERE id = ?', {vehData.id})
    end
end)

RegisterNetEvent('stw-carauction:server:WithdrawMoney', function(amount)
    local src = source
    if not QBCore.Functions.HasPermission(src, 'admin') and not CheckJobPermission(src, Config.Job.minGradeManager) then 
        TriggerClientEvent('QBCore:Notify', src, 'Access Denied', 'error')
        return 
    end
    
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    
    local result = MySQL.query.await('SELECT amount FROM car_auction_money WHERE id = 1')
    if result and result[1] then
        local currentBalance = result[1].amount
        if currentBalance >= amount then
            MySQL.update('UPDATE car_auction_money SET amount = amount - ? WHERE id = 1', {amount})
            Player.Functions.AddMoney('cash', amount, "auction-withdraw")
            TriggerClientEvent('QBCore:Notify', src, 'Withdrew $' .. amount, 'success')
        else
            TriggerClientEvent('QBCore:Notify', src, 'Insufficient funds in auction account', 'error')
        end
    end
end)

RegisterNetEvent('stw-carauction:server:GetAuctionBalance', function()
    local src = source
    if not QBCore.Functions.HasPermission(src, 'admin') and not CheckJobPermission(src, Config.Job.minGradeManager) then
        TriggerClientEvent('QBCore:Notify', src, 'Access Denied', 'error')
        return
    end
    
    local result = MySQL.query.await('SELECT amount FROM car_auction_money WHERE id = 1')
    local balance = 0
    if result and result[1] then
        balance = result[1].amount
    end
    TriggerClientEvent('stw-carauction:client:OpenMoneyMenu', src, balance)
end)

RegisterNetEvent('stw-carauction:server:ToggleDuty', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    
    if Player.PlayerData.job.name == Config.Job.name then
        if Player.PlayerData.job.onduty then
            Player.Functions.SetJobDuty(false)
            TriggerClientEvent('QBCore:Notify', src, 'Off Duty', 'error')
        else
            Player.Functions.SetJobDuty(true)
            TriggerClientEvent('QBCore:Notify', src, 'On Duty', 'success')
        end
        TriggerClientEvent('QBCore:Client:SetDuty', src, Player.PlayerData.job.onduty)
    else
        TriggerClientEvent('QBCore:Notify', src, 'You do not work here!', 'error')
    end
end)

RegisterNetEvent('stw-carauction:server:GetEmployees', function()
    local src = source
    if not CheckJobPermission(src, Config.Job.minGradeManager) then return end
    
    local employees = {}
    local players = QBCore.Functions.GetQBPlayers()
    for _, v in pairs(players) do
        if v.PlayerData.job.name == Config.Job.name then
            table.insert(employees, {
                name = v.PlayerData.charinfo.firstname .. ' ' .. v.PlayerData.charinfo.lastname,
                citizenid = v.PlayerData.citizenid,
                grade = v.PlayerData.job.grade,
                source = v.PlayerData.source,
                isOnline = true
            })
        end
    end
    
    local dbResult = MySQL.query.await('SELECT * FROM players WHERE job LIKE ?', {'%' .. Config.Job.name .. '%'})
    local allEmployees = {}
    
    if dbResult then
        for _, v in ipairs(dbResult) do
            local job = json.decode(v.job)
            local charinfo = json.decode(v.charinfo)
            if job.name == Config.Job.name then
                table.insert(allEmployees, {
                    name = charinfo.firstname .. ' ' .. charinfo.lastname,
                    citizenid = v.citizenid,
                    grade = job.grade,
                    isOnline = QBCore.Functions.GetPlayerByCitizenId(v.citizenid) ~= nil
                })
            end
        end
    end

    TriggerClientEvent('stw-carauction:client:OpenEmployeeMenu', src, allEmployees)
end)

RegisterNetEvent('stw-carauction:server:HireEmployee', function(targetId)
    local src = source
    if not CheckJobPermission(src, Config.Job.minGradeManager) then return end
    
    local Target = QBCore.Functions.GetPlayer(tonumber(targetId))
    if Target then
        Target.Functions.SetJob(Config.Job.name, 0)
        TriggerClientEvent('QBCore:Notify', src, 'Hired ' .. Target.PlayerData.charinfo.firstname, 'success')
        TriggerClientEvent('QBCore:Notify', Target.PlayerData.source, 'You have been hired at the Auction!', 'success')
    else
        TriggerClientEvent('QBCore:Notify', src, 'Player not found', 'error')
    end
end)

RegisterNetEvent('stw-carauction:server:FireEmployee', function(citizenid)
    local src = source
    if not CheckJobPermission(src, Config.Job.minGradeManager) then return end
    
    local Target = QBCore.Functions.GetPlayerByCitizenId(citizenid)
    if Target then
        Target.Functions.SetJob('unemployed', 0)
        TriggerClientEvent('QBCore:Notify', src, 'Fired employee', 'success')
        TriggerClientEvent('QBCore:Notify', Target.PlayerData.source, 'You have been fired!', 'error')
    else
        local player = MySQL.query.await('SELECT * FROM players WHERE citizenid = ?', {citizenid})
        if player and player[1] then
            local job = json.decode(player[1].job)
            job.name = "unemployed"
            job.grade = {level = 0, name = "Unemployed"}
            MySQL.update('UPDATE players SET job = ? WHERE citizenid = ?', {json.encode(job), citizenid})
            TriggerClientEvent('QBCore:Notify', src, 'Fired offline employee', 'success')
        end
    end
end)

RegisterNetEvent('stw-carauction:server:PromoteEmployee', function(citizenid, newGrade)
    local src = source
    if not CheckJobPermission(src, Config.Job.minGradeManager) then return end
    
    local Target = QBCore.Functions.GetPlayerByCitizenId(citizenid)
    if Target then
        Target.Functions.SetJob(Config.Job.name, tonumber(newGrade))
        TriggerClientEvent('QBCore:Notify', src, 'Updated employee grade', 'success')
        TriggerClientEvent('QBCore:Notify', Target.PlayerData.source, 'Your job grade has been updated!', 'success')
    else
         local player = MySQL.query.await('SELECT * FROM players WHERE citizenid = ?', {citizenid})
        if player and player[1] then
            local job = json.decode(player[1].job)
            job.grade.level = tonumber(newGrade)
            MySQL.update('UPDATE players SET job = ? WHERE citizenid = ?', {json.encode(job), citizenid})
            TriggerClientEvent('QBCore:Notify', src, 'Updated offline employee grade', 'success')
        end
    end
end)

function StartAuction(data, price, time, minBid, managerSource, netId)
    if AuctionState.active then return end

    local vehicleModel = data.vehicle
    local label = vehicleModel
    if QBCore.Shared.Vehicles[vehicleModel] then
        label = QBCore.Shared.Vehicles[vehicleModel].name .. " (" .. QBCore.Shared.Vehicles[vehicleModel].brand .. ")"
    end
    
    if data.plate then
        label = label .. " [" .. data.plate .. "]"
    end

    AuctionState.active = true
    AuctionState.vehicleLabel = label
    AuctionState.price = price
    AuctionState.bidder = "None"
    AuctionState.bidderSource = nil
    AuctionState.bidderCitizenId = nil
    AuctionState.time = time or Config.Auction.InitialTime
    AuctionState.minBid = minBid or Config.Auction.MinimumBid
    AuctionState.vehicleData = data
    AuctionState.managerSource = managerSource
    AuctionState.netId = netId
    
    print("||  Stw Free Car Auction Script | Join Our Discord: https://discord.gg/7vrxEge64p  ||")

    TriggerClientEvent('stw-carauction:client:UpdateAuction', -1, AuctionState)
    
    CreateThread(function()
        while AuctionState.active do
            Wait(1000)
            if AuctionState.time > 0 then
                AuctionState.time = AuctionState.time - 1
                TriggerClientEvent('stw-carauction:client:UpdateAuction', -1, AuctionState)
            else
                EndAuction()
            end
        end
    end)
end

function EndAuction()
    print("||  Stw Free Car Auction Script | Join Our Discord: https://discord.gg/7vrxEge64p  ||")
    AuctionState.active = false
    TriggerClientEvent('stw-carauction:client:UpdateAuction', -1, AuctionState)
    TriggerClientEvent('QBCore:Notify', -1, 'Auction Ended! Winner: ' .. AuctionState.bidder, 'success')

    if AuctionState.managerSource then
        TriggerClientEvent('stw-carauction:client:DeliverVehicle', AuctionState.managerSource, AuctionState.bidderSource ~= nil)
    end

    if AuctionState.bidderSource and AuctionState.bidderCitizenId then
        local Player = QBCore.Functions.GetPlayer(AuctionState.bidderSource)
        if Player then
             if Player.Functions.RemoveMoney('bank', AuctionState.price, "auction-won") then
                TriggerClientEvent('QBCore:Notify', AuctionState.bidderSource, 'You won the auction for $' .. AuctionState.price, 'success')
                
                MySQL.query('UPDATE car_auction_money SET amount = amount + ? WHERE id = 1', {AuctionState.price})

                if AuctionState.vehicleData and AuctionState.vehicleData.id then
                    local vid = AuctionState.vehicleData.id
                    local vehInfo = MySQL.query.await('SELECT * FROM auction_vehicles WHERE id = ?', {vid})
                    if vehInfo and vehInfo[1] then
                        local v = vehInfo[1]
                        MySQL.insert('INSERT INTO player_vehicles (citizenid, license, vehicle, hash, mods, plate, garage, state) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', {
                            Player.PlayerData.citizenid,
                            Player.PlayerData.license,
                            v.vehicle,
                            v.hash,
                            v.mods,
                            v.plate,
                            'pillboxgarage',
                            0
                        })
                        MySQL.query('DELETE FROM auction_vehicles WHERE id = ?', {vid})
                        TriggerClientEvent('QBCore:Notify', AuctionState.bidderSource, 'Your vehicle is being delivered!', 'success')
                        TriggerClientEvent('vehiclekeys:client:SetOwner', AuctionState.bidderSource, v.plate)
                    end
                end
             else
                TriggerClientEvent('QBCore:Notify', AuctionState.bidderSource, 'You could not afford the final price!', 'error')
                if AuctionState.vehicleData and AuctionState.vehicleData.id then
                    MySQL.update('UPDATE auction_vehicles SET state = 0 WHERE id = ?', {AuctionState.vehicleData.id})
                end
             end
        else
             if AuctionState.vehicleData and AuctionState.vehicleData.id then
                MySQL.update('UPDATE auction_vehicles SET state = 0 WHERE id = ?', {AuctionState.vehicleData.id})
            end
        end
    else
        if AuctionState.vehicleData and AuctionState.vehicleData.id then
            MySQL.update('UPDATE auction_vehicles SET state = 0 WHERE id = ?', {AuctionState.vehicleData.id})
        end
    end
end

RegisterNetEvent('stw-carauction:server:PlaceBid', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not AuctionState.active then
        TriggerClientEvent('QBCore:Notify', src, 'No active auction!', 'error')
        return
    end
    
    local cardItem = Player.Functions.GetItemByName(Config.AuctionCardItem)
    if not cardItem then
        TriggerClientEvent('QBCore:Notify', src, 'You need an Auction Card', 'error')
        return
    end
    
    if AuctionState.bidderSource == src then
        TriggerClientEvent('QBCore:Notify', src, 'You are already the highest bidder!', 'error')
        return
    end

    local minIncrement = AuctionState.minBid or Config.Auction.MinimumBid
    local newPrice = AuctionState.price + minIncrement
    
    if Player.PlayerData.money.bank >= newPrice then
        AuctionState.price = newPrice
        AuctionState.bidder = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname
        AuctionState.bidderSource = src
        AuctionState.bidderCitizenId = Player.PlayerData.citizenid
        AuctionState.time = AuctionState.time + Config.Auction.IncrementTime
        
        print("||  Stw Free Car Auction Script | Join Our Discord: https://discord.gg/7vrxEge64p  ||")
        
        TriggerClientEvent('QBCore:Notify', -1, 'New Bid placed by ' .. AuctionState.bidder, 'primary')
        TriggerClientEvent('stw-carauction:client:UpdateAuction', -1, AuctionState)
    else
        TriggerClientEvent('QBCore:Notify', src, 'Not enough money in bank!', 'error')
    end
end)

RegisterNetEvent('stw-carauction:server:BuyAuctionCard', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    local price = Config.AuctionCardPrice
    if Player.Functions.RemoveMoney('cash', price, 'auction-card') then
        local added = Player.Functions.AddItem(Config.AuctionCardItem, 1)
        if added then
            TriggerClientEvent('QBCore:Notify', src, 'Purchased Auction Card', 'success')
        else
            Player.Functions.AddMoney('cash', price, 'auction-card-failed')
            TriggerClientEvent('QBCore:Notify', src, 'Item not available', 'error')
        end
    else
        TriggerClientEvent('QBCore:Notify', src, 'Not enough cash', 'error')
    end
end)

QBCore.Functions.CreateCallback('stw-carauction:server:HasAuctionCard', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then cb(false) return end
    local item = Player.Functions.GetItemByName(Config.AuctionCardItem)
    cb(item ~= nil)
end)

Config = {}

Config.AuctionZone = {
    center = vector3(-1090.48, -1271.35, 5.85),
    length = 15.8,
    width = 19.0,
    heading = 30,
    minZ = 4.45,
    maxZ = 8.45,
    debug = false
}

Config.GarageZone = {
    center = vector3(-1108.72, -1260.89, 4.65),
    length = 5.2,
    width = 9.2,
    heading = 30,
    minZ = 2.45,
    maxZ = 6.45,
    debug = false
}

Config.BossMenu = vector3(-1085.48, -1265.75, 5.77)
Config.AuctionDriveBuySpot = vector4(-1082.76, -1254.27, 4.81, 300.31)

Config.AuctionDriveStart = vector4(-1111.96, -1271.51, 4.74, 301.27)
Config.AuctionDriveSpot = vector4(-1096.26, -1262.09, 5.58, 299.97)

Config.Job = {
    name = "mosely",
    minGradeStart = 1,
    minGradeManager = 2
}

Config.Auction = {
    InitialTime = 120,
    IncrementTime = 10,
    MinimumBid = 500
}

Config.AuctionCardPed = vector4(-1084.157, -1266.863, 5.8471288, 128.40158)
Config.AuctionCardItem = "auctioncard"
Config.AuctionCardPrice = 5000
